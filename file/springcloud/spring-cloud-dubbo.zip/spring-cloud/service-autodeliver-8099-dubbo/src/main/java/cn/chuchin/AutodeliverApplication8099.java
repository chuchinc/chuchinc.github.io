package cn.chuchin;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class AutodeliverApplication8099 {

    public static void main(String[] args) {
        SpringApplication.run(AutodeliverApplication8099.class,args);
    }

}
