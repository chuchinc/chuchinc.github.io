package cn.chuchin.controller;

import cn.chuchin.config.SentinelHandlersClass;
import cn.chuchin.service.ResumeService;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/autodeliver")
public class AutodeliverController {

    @Reference
    private ResumeService resumeService;

    /**
     * @SentinelResource
     *  value： 定义资源名
     *  blockHandlerClass：指定Sentinel规则异常兜底逻辑所在的class类
     *  blockHandler：指定Sentinel规则异常兜底逻辑具体哪个方法
     *  fallbackClass：指定Java运⾏时异常兜底逻辑所在class类
     *  fallback：指定Java运⾏时异常兜底逻辑具体哪个⽅法
     * @param userId
     * @return
     */
    @GetMapping("/checkState/{userId}")
    // @SentinelResource注解类似于Hystrix中的@HystrixCommand注解
    @SentinelResource(value = "findResumeOpenState",blockHandlerClass = SentinelHandlersClass.class,
            blockHandler = "handleException",fallbackClass = SentinelHandlersClass.class,fallback = "handleError")
    public Integer findResumeOpenState(@PathVariable Long userId) {
        return resumeService.findDefaultResumeByUserId(userId);
    }






}
