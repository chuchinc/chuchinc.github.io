package cn.chuchin.controller;

import cn.chuchin.config.SentinelHandlersClass;
import cn.chuchin.controller.service.ResumeServiceFeignClient;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/autodeliver")
public class AutodeliverController {


    @Autowired
    private ResumeServiceFeignClient resumeServiceFeignClient;

    /**
     * @SentinelResource
     *  value： 定义资源名
     *  blockHandlerClass：指定Sentinel规则异常兜底逻辑所在的class类
     *  blockHandler：指定Sentinel规则异常兜底逻辑具体哪个方法
     *  fallbackClass：指定Java运⾏时异常兜底逻辑所在class类
     *  fallback：指定Java运⾏时异常兜底逻辑具体哪个⽅法
     * @param userId
     * @return
     */
    @GetMapping("/checkState/{userId}")
    // @SentinelResource注解类似于Hystrix中的@HystrixCommand注解
    @SentinelResource(value = "findResumeOpenState",blockHandlerClass = SentinelHandlersClass.class,
            blockHandler = "handleException",fallbackClass = SentinelHandlersClass.class,fallback = "handleError")
    public Integer findResumeOpenState(@PathVariable Long userId) {
        // 模拟降级：
        /*try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        // 模拟降级：异常比例
        //int i = 1/0;
        Integer defaultResumeState = resumeServiceFeignClient.findDefaultResumeState(userId);
        return defaultResumeState;
    }






}
