package cn.chuchin.service;


import cn.chuchin.pojo.Resume;

public interface ResumeService {

    Resume findDefaultResumeByUserId(Long userId);
}
