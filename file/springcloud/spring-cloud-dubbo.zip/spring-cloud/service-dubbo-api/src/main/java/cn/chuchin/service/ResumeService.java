package cn.chuchin.service;

public interface ResumeService {

    Integer findDefaultResumeByUserId(Long userId);
}
