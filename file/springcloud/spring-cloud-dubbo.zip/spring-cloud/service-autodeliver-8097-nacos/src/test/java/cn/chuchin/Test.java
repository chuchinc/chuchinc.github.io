package cn.chuchin;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-12-07 17:09
 */
@SpringBootTest(classes = {AutodeliverApplication8097.class})
@RunWith(SpringJUnit4ClassRunner.class)
public class Test {

    @Autowired
    private RestTemplate restTemplate;

    @org.junit.Test
    public void testRibbon() {
        // 客户端面对的其实是服务了----service-resume，具体访问到哪个实例是由ribbon决定的
        String url = "http://service-resume/resume/openstate/1545136";
        // 调用远程服务—> 简历微服务接口  RestTemplate  -> JdbcTempate
        // httpclient封装好多内容进行远程调用
        Integer forObject = restTemplate.getForObject(url, Integer.class);
        System.out.println("=====》》》使用ribbon负载均衡访问，访问的服务实例的端口号：" + forObject);
    }
}

