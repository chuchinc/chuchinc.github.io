package cn.chuchin.controller;

import cn.chuchin.controller.service.ResumeFeignClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-11-30 13:55
 */
@Slf4j
@RestController
@RequestMapping("/autodeliver")
public class AutoDeliverController {

    @Autowired
    private ResumeFeignClient resumeFeignClient;

    @RequestMapping(value = "/checkState/{userId}", method = RequestMethod.GET)
    public Integer findResumeOpenState(@PathVariable Long userId) {
        return resumeFeignClient.findResumeOpenState(userId);
    }
}

