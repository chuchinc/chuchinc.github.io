package cn.chuchin.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-12-01 14:15
 */
@RestController
@RequestMapping("/server")
public class ServerPortController {

    @Value("${server.port}")
    private Integer port;

    @GetMapping("/port")
    public Integer getServerPort() {
        return port;
    }

}

