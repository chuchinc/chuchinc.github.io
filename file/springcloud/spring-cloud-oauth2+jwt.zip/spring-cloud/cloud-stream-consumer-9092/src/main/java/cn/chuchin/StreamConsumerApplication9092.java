package cn.chuchin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-12-03 15:11
 */
@SpringBootApplication
@EnableDiscoveryClient
public class StreamConsumerApplication9092 {

    public static void main(String[] args) {
        SpringApplication.run(StreamConsumerApplication9092.class, args);
    }

}

