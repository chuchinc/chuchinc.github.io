package cn.chuchin.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-12-03 16:00
 */
@Component
@Slf4j
public class SendScheduled {

    @Autowired
    private IMessageProducer iMessageProducer;

    @Scheduled(cron = "*/5 * * * * ?")
    public void testSendMessage() {
        iMessageProducer.sendMessage("Hello world");
        log.info("======send=======");
    }

}

