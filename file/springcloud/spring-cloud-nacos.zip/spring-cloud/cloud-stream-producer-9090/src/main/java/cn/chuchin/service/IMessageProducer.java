package cn.chuchin.service;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-12-03 15:15
 */
public interface IMessageProducer {

    void sendMessage(String content);

}

