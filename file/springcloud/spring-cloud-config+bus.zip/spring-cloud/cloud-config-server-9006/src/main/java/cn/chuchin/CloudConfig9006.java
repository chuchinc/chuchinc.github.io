package cn.chuchin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.config.server.EnableConfigServer;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-12-03 10:45
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableConfigServer
public class CloudConfig9006 {

    public static void main(String[] args) {
        SpringApplication.run(CloudConfig9006.class, args);
    }
}

