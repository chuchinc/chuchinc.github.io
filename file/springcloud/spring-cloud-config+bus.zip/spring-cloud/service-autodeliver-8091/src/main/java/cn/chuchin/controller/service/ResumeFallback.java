package cn.chuchin.controller.service;

import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-12-02 13:56
 */
@Component
public class ResumeFallback implements ResumeFeignClient{

    /**
     * 调用请求路径
     */
    @Override
    public Integer findResumeOpenState(Long userId) {
        return -10086;
    }
}

