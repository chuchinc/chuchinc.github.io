package cn.chuchin.controller.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-12-02 10:58
 */
//调用的服务名称，和服务提供者yml文件中spring.application.name保持一致
// 使⽤fallback的时候，类上的 @RequestMapping的url前缀限定，改成配置在@FeignClient的path属性中 //@RequestMapping("/resume")
@FeignClient(name = "service-resume", fallback = ResumeFallback.class, path = "/resume")
public interface ResumeFeignClient {

    /**
     * 调用请求路径
     * @param userId
     * @return
     */
    @RequestMapping(value = "/openstate/{userId}", method = RequestMethod.GET)
    Integer findResumeOpenState(@PathVariable(value = "userId") Long userId);

}

