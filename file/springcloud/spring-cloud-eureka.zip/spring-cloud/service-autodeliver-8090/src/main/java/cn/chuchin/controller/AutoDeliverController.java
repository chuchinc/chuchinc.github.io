package cn.chuchin.controller;

import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-11-30 13:55
 */
@Slf4j
@RestController
@RequestMapping("/autodeliver")
public class AutoDeliverController {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private DiscoveryClient discoveryClient;

    @GetMapping("/checkState/{userId}")
    public Integer findResumeOpenState(@PathVariable Long userId) {
        //获取Eureka中注册的实例列表
        List<ServiceInstance> instances = discoveryClient.getInstances("service-resume");
        //获取实例, 此处不考虑负载，就拿第一个
        ServiceInstance serviceInstance = instances.get(0);
        //根据实例的信息拼接请求地址
        String host = serviceInstance.getHost();
        int port = serviceInstance.getPort();
        String url = "http://" + host + ":" + port + "/resume/openstate/" + userId;
        //消费者直接调用提供者
        Integer forObject = restTemplate
                .getForObject(url, Integer.class);
        log.info("调用简历微服务，获取用户： " + userId + " 默认简历当前状态为: " + forObject);
        return forObject;
    }
}

