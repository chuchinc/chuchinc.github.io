package cn.chuchin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * @Description
 * @Author ChinHeng-Chu
 * @Date 2020-11-30 15:41
 */
@SpringBootApplication
@EnableEurekaServer
public class CloudEurekaApplication8761 {

    public static void main(String[] args) {
        SpringApplication.run(CloudEurekaApplication8761.class, args);
    }
}

