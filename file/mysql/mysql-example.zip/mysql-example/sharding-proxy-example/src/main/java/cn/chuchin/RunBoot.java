package cn.chuchin;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunBoot {
}
