---
title: "Java核心技术 卷1 原书11版"
date: 2020-01-12T21:52:04+08:00
draft: false
tags: ["Java"]
---

![20201210-131247-0166.jpg](https://gitee.com/chuchin/img/raw/master/20201210-131247-0166.jpg)

满减买了几本，经典之作，值得反复看，看完再入手卷2，书中部分代码：[https://github.com/chuchinc/kl-book-resource](https://github.com/chuchinc/kl-book-resource)

