---
title: "labuladong的算法小抄"
date: 2020-12-06T21:52:04+08:00
draft: false
tags: ["算法"]
---

![20201210-131047-0038.jpg](https://gitee.com/chuchin/img/raw/master/20201210-131047-0038.jpg)

博主公众号粉丝，微信公众号名就叫“labuladong”，预售拿到了这本书，大部分内容来自公众号文章和pdf，纯支持。